package com.example.project5;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DataBaseManagement mDBManager;
    TextView mBalanceTv;
    Button mAddBtn, mSubBtn;
    EditText mDateEdit, mPriceEdit, mItemEdit;
    TableLayout mHistoryTl;

    DecimalFormat df = new DecimalFormat("0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBalanceTv = (TextView) findViewById(R.id.balance);
        mDateEdit = (EditText) findViewById(R.id.editDate);
        mPriceEdit = (EditText) findViewById(R.id.editPrice);
        mItemEdit = (EditText) findViewById(R.id.editItem);
        mAddBtn = (Button) findViewById(R.id.btnAdd);
        mSubBtn = (Button) findViewById(R.id.btnSub);
        mHistoryTl = (TableLayout) findViewById(R.id.tableHistory);

        mDBManager = new DataBaseManagement(this);

        AddBtnListener();
        GetHistory();
    }

    public void AddBtnListener(){
        mAddBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        double price = Double.parseDouble(mPriceEdit.getText().toString());
                        BalanceModel model = new BalanceModel();
                        model.mDate =  mDateEdit.getText().toString();
                        model.mItem = mItemEdit.getText().toString();
                        model.mPrice = price;
                        boolean result = mDBManager.createHistory(model);
                        if (result)
                            Toast.makeText(MainActivity.this, "Successfully Created", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "Failed to Create", Toast.LENGTH_LONG).show();
                        GetHistory();
                        ClearTextView();
                    }
                }
        );

        mSubBtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        double price = -1 * Double.parseDouble(mPriceEdit.getText().toString());
                        BalanceModel model = new BalanceModel();
                        model.mDate =  mDateEdit.getText().toString();
                        model.mItem = mItemEdit.getText().toString();
                        model.mPrice = price;
                        boolean result = mDBManager.createHistory(model);
                        if (result)
                            Toast.makeText(MainActivity.this, "Successfully Created", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this, "Failed to Create", Toast.LENGTH_LONG).show();
                        GetHistory();
                        ClearTextView();
                    }
                }
        );
    }

    public void GetHistory(){
        ClearTableLayout();
        Cursor result = mDBManager.pullData();
        StringBuffer buffer = new StringBuffer();
        Double balance = 0.0;

        while(result.moveToNext()){
            TableRow tr = new TableRow(this);
            TableRow.LayoutParams columnLayout = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
            columnLayout.weight = 1;
            columnLayout.gravity = Gravity.CENTER;

            TextView dateTv = new TextView(this);
            dateTv.setLayoutParams(columnLayout);
            dateTv.setText(result.getString(2));
            tr.addView(dateTv);

            TextView priceTv = new TextView(this);
            priceTv.setLayoutParams(columnLayout);
            priceTv.setText(result.getString(3));
            tr.addView(priceTv);

            TextView itemTv = new TextView(this);
            itemTv.setLayoutParams(columnLayout);
            itemTv.setText(result.getString(1));
            tr.addView(itemTv);

            mHistoryTl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            double price = Double.parseDouble(result.getString(3));
            balance += price;
        }
        MainActivity.this.mBalanceTv.setText("Current Balance: $" + df.format(balance));
    }

    public void ClearTextView(){
        MainActivity.this.mDateEdit.setText("");
        MainActivity.this.mPriceEdit.setText("");
        MainActivity.this.mItemEdit.setText("");
    }

    public void ClearTableLayout(){
        int count = mHistoryTl.getChildCount();
        for (int i = 1; i < count; i++) {
            mHistoryTl.removeViewAt(1);
        }
    }

}
