package com.example.project5;

public class BalanceModel {
    String mItem;
    String mDate;
    double mPrice;
}
